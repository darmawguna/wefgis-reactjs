import LayoutComponent from "../layouts/Layout"

const LandingPage = () => {
    return (
        <>
            <LayoutComponent />
        </>
    )
}

export default LandingPage
