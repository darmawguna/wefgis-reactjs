import LayoutMap from "../layouts/map/LayoutMap"


const MapBar = () => {
    return (
        <>
            <LayoutMap />
        </>
    )
}

export default MapBar