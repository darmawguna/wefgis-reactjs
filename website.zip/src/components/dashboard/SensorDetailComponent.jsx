

const SensorDetailComponent = () => {
    return (
        <>
            <div className="flex">
                <div className="border border-gray-300 p-4 w-2/3 h-96">
                    Detail Sensor
                </div>
                <div className="border border-gray-300 p-4 w-1/3 h-48 ml-4">
                    Grafik
                </div>
            </div>
        </>
    )
}

export default SensorDetailComponent
